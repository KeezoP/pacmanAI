#pragma once
#include <SFML\Graphics.hpp>
#include "Collider.h"
class Junction
{

	public:
		Junction(sf::Vector2f size, sf::Vector2f position,std::string path, int colourID, int objID);
		~Junction();

		void Draw(sf::RenderWindow& window);
		int returnType() { return typeID; }
		int returnID() { return objID; }
		sf::Vector2f getPosition() { return body.getPosition(); }
		std::string getPath() { return path; }
		Collider getCollider() { return Collider(body); }
	private:
		sf::RectangleShape body;
		int typeID;
		int objID;
		std::string path;
};

