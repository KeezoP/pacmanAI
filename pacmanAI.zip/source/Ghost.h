#pragma once
#include <SFML\Graphics.hpp>
#include "Collider.h"
class Ghost
{
public:
	Ghost(int,sf::Vector2f);
	~Ghost();

	void applyMovement(float deltaTime);
	void Draw(sf::RenderWindow& window);
	void calcDirection(sf::Vector2f,int,sf::Vector2f, std::string,int);
	sf::Vector2f calcTarget(sf::Vector2f,int,sf::Vector2f);
	void setPosition(sf::Vector2f);
	void setColour();
	float getDistance(sf::Vector2f, sf::Vector2f);
	int direction = 0;
	float speed;
	int ghostID;
	int ghostMode;
	bool ghostFrighten;
	sf::Vector2f Scatter();
	sf::Vector2f getPosition() { return body.getPosition(); }
	Collider getCollider() { return Collider(body); }
private:
	sf::RectangleShape body;


};

