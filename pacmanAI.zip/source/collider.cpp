
#include "Collider.h"
#include "Pellet.h"
Collider::Collider(sf::RectangleShape& body) :
    body(body)
{

}

Collider::~Collider()
{
}

bool Collider::checkCollision(Collider other, float push, int objID)
{
    sf::Vector2f otherPosition = other.getPosition();
    sf::Vector2f otherHalfSize = other.getHalfSize();
    sf::Vector2f thisPosition = getPosition();
    sf::Vector2f thisHalfSize = getHalfSize();

    float deltaX = otherPosition.x - thisPosition.x;
    float deltaY = otherPosition.y - thisPosition.y;

    float intersectX = abs(deltaX) - (otherHalfSize.x + thisHalfSize.x);
    float intersectY = abs(deltaY) - (otherHalfSize.y + thisHalfSize.y);

    //if interesecting
    if (intersectX < 0.0f && intersectY < 0.0f) {
        float scale = 2;
        float offset = 20;
        float x;
        float y;
        bool drx = false;
        bool dry = false;
        float range = 0.1f;
        switch (objID) {

        case 0:
            push = std::min(std::max(push, 0.0f), 1.0f);

            if (intersectX > intersectY) {
                if (deltaX > 0.0f) {
                    Move(intersectX * (1 - push), 0.0f);
                    other.Move(-intersectX * push, 0.0f);
                }
                else {
                    Move(-intersectX * (1 - push), 0.0f);
                    other.Move(intersectX * push, 0.0f);
                }
                return true;
            }

            else if (intersectX < intersectY) {
                if (deltaY > 0.0f) {
                    Move(0.0f, intersectY * (1 - push));
                    other.Move(0.0f, -intersectY * push);
                }
                else {
                    Move(0.0f, -intersectY * (1 - push));
                    other.Move(0.0f, intersectY * push);
                }
                return true;
            }
            

            return false;
            break;

        case 1:
            
            x = ((280 + (10 / 2)) + offset) * scale;
            y = ((140 + (10 / 2)) + offset) * scale;

            other.body.setPosition(sf::Vector2f(x, y));
            return true;
            break;

        case 2:
            x = ((-10 + (10 / 2)) + offset) * scale;
            y = ((140 + (10 / 2)) + offset) * scale;

            other.body.setPosition(sf::Vector2f(x,y));
            return true;
            break;

        case 3:
            // delta range boolean

                if (deltaX < range && deltaX > -range) {
                    drx = true;
                }

                if (deltaY < range && deltaY > -range) {
                    dry = true;
                }

                if (drx && dry) {
                    if (deltaX != 0 || deltaY != 0) {
                        return true;
                    }
                }
            
            break;
        case 4:

            if (intersectX < -19.0f && intersectY < -19.0f)
            {
                return true;
            }

            break;
        case 5:
            //if any intersection 
            return true;
            break;
        }
    }
    return false;
}
