#pragma once
#include <SFML\Graphics.hpp>
#include "Collider.h"
#include "Pellet.h"
#include "Ghost.h"
#include <iostream>

class Player
{
public:
	Player(float speed, sf::Vector2f spawn);
	~Player();
	int life = 100;
	void applyMovement(float deltaTime);
	void Draw(sf::RenderWindow& window);
	void userInput();
	void setPosition(sf::Vector2f);
	
	int direction;
	float timer;
	int score;
	float countdownTimer;
	int junctionID;
	sf::Vector2f junctionCore;
	std::string junctionPath;
	
	void ai(Pellet Pellets[],int,Pellet BigPellets[], int, Ghost GhostGroup1[],int);
	void fsmState0();
	void fsmState1(Pellet Pellets[], int);
	void fsmState2(Pellet Pellets[], int);
	void fsmState3(Ghost Ghost[], int, Pellet Pellets[], int);
	void fsmState4(Ghost Ghost[], int, Pellet Pellets[], int pCount);
	int ghostsInRange(Ghost Ghost[], int);
	void fsmState5();
	float calcDistance(sf::Vector2f, sf::Vector2f);
	void calcDirection(sf::Vector2f);
	void calcRunToDirection(sf::Vector2f,int, Pellet Pellets[],int);
	int getClosestPellet(Pellet pellets[], int);
	void setJunction(sf::Vector2f, int, std::string);
	sf::Vector2f getPosition() { return body.getPosition(); }
	Collider getCollider() { return Collider(body); }
private:
	sf::RectangleShape body;
	int fsmState;
	sf::Vector2f spawnPos;
	float speed;
};

