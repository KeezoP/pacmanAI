#include <SFML/Graphics.hpp>
#include "Player.h"
#include "Wall.h"
#include "Junction.h"
#include "Pellet.h"
#include "Ghost.h"
#include <fstream>

static const float VIEW_HEIGHT = 1000.0f;
void resizeView(const sf::RenderWindow& window, sf::View& view) {
    float aspectRatio = float(window.getSize().x) / float(window.getSize().y);
    view.setSize(VIEW_HEIGHT * aspectRatio, VIEW_HEIGHT);
}

// used to return 2 vectors from function calcBlock
struct sizePos { sf::Vector2f size; sf::Vector2f position; };

/* 
    Normally SFML draws objects via their TL corner
    for collision calcs, i need to draw objects via their center

    function calcBlock helps me calc the new size and position required
*/

sizePos calcBlock(float width, float height, float x, float y, float scale) {
    sizePos result;
    float offset = 20;
    result.size = sf::Vector2f(width * scale, height * scale);
    result.position.x = ((x + (width / 2))+offset)*scale;
    result.position.y = ((y + (height / 2))+offset)*scale;
    return result;
}

int main()
{

    sf::RenderWindow window(sf::VideoMode(1000.0f, 1000.0f), "SFML Tutorial", sf::Style::Close | sf::Style::Resize);
    //sf::View view(sf::Vector2f(0.0f, 0.0f), sf::Vector2f(VIEW_HEIGHT, VIEW_HEIGHT));

    int ghostJuncID[] = {0,0,0,0};
    bool ghostJuncTouch[] = {false,false,false,false};
    
    Player player1(50.0f,sf::Vector2f(140.0f,235.0f));
    
    Ghost red1(1, sf::Vector2f(140.0f,115.0f));
    Ghost pink1(2, sf::Vector2f(140.0f,145.0f));
    Ghost blue1(3, sf::Vector2f(125.0f,145.0f));
    Ghost orange1(4, sf::Vector2f(155.0f,145.0f));
    Ghost GhostGroup1[] = {red1,pink1,blue1,orange1};
    

    float scale = 2.0f;
    float deltaTime = 0.0f;
    float bigPelletTime = 6.0f;
    bool limitGhostCheck = false;
    sf::Clock clock;
    sizePos sp;
    bool allowChange = true;

    bool gameEnd = false;   // used for checking game over
    bool countDown = false; // used for frightened ghost mode
    bool jCheck = false; // checks if player is inside junction
    
    sf::Vector2f junctionCore(0.0f, 0.0f);
    sf::Vector2f ghostMemory[] = { junctionCore,junctionCore ,junctionCore ,junctionCore };
    int gdm[] = { 0,0,0,0 };

    bool debug = false; // used for debugging
    bool gameBegin = false;
    bool allowClear = false;

    // used to juggle ghosts decision making
    int timeScript = 0;
    int swapMode = false;
    bool limitSwap = false;

    // used to make pacman only take damage once, then immunity for 4 seconds
    float iframes = 4.0f;
    bool damage = false; 
    
    // loads font
    sf::Font font;
    if (!font.loadFromFile("Square.ttf")) {
        printf("fail");
    }

    int activeGhosts = 2; // how many ghosts are moving (default 2)

    /*
        output for player lives, score & timer, each split in two parts
        part 1 is constant, part 2 is a string that updates every frame
    */

    sf::Text p1Life1; sf::Text p1Life2;
    sf::Text p1Score1; sf::Text p1Score2;  
    sf::Text p1Timer1; sf::Text p1Timer2;

    // set the font
    p1Life1.setFont(font); p1Life2.setFont(font);
    p1Score1.setFont(font); p1Score2.setFont(font); 
    p1Timer1.setFont(font); p1Timer2.setFont(font);
 
    // set the size
    p1Life1.setCharacterSize(24); p1Life2.setCharacterSize(24);
    p1Score1.setCharacterSize(24); p1Score2.setCharacterSize(24);
    p1Timer1.setCharacterSize(24); p1Timer2.setCharacterSize(24);
    
    // set the colour
    p1Life1.setFillColor(sf::Color::Yellow);
    p1Life2.setFillColor(sf::Color::Yellow);
    p1Score1.setFillColor(sf::Color::Yellow);
    p1Score2.setFillColor(sf::Color::Yellow);
    p1Timer1.setFillColor(sf::Color::Yellow);
    p1Timer2.setFillColor(sf::Color::Yellow);

    // set the position
    p1Life1.setPosition(sf::Vector2f(20.0f * scale, 340.0f * scale));
    p1Life2.setPosition(sf::Vector2f(60.0f * scale, 340.0f * scale));
    p1Score1.setPosition(sf::Vector2f(100.0f * scale, 340.0f * scale));
    p1Score2.setPosition(sf::Vector2f(145.0f * scale, 340.0f * scale));
    p1Timer1.setPosition(sf::Vector2f(210.0f * scale, 340.0f * scale));
    p1Timer2.setPosition(sf::Vector2f(245.0f * scale, 340.0f * scale));

    // set the style
    p1Life1.setStyle(sf::Text::Bold | sf::Text::Underlined);
    p1Life2.setStyle(sf::Text::Bold | sf::Text::Underlined);
    p1Score1.setStyle(sf::Text::Bold | sf::Text::Underlined);
    p1Score2.setStyle(sf::Text::Bold | sf::Text::Underlined);
    p1Timer1.setStyle(sf::Text::Bold | sf::Text::Underlined);
    p1Timer2.setStyle(sf::Text::Bold | sf::Text::Underlined);

    // set the string
    p1Life1.setString("Lives:  ");
    p1Score1.setString("Score:  ");
    p1Timer1.setString("Time:  ");


    ///// LOAD DATA FROM FILE SECTION /////

    // loads junctions from file
    std::ifstream jfile("junctions2.txt");
    Junction j(sf::Vector2f(0, 0), sf::Vector2f(0, 0),"", 0, 0);
    Junction Junctions[] = {
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j,j,j,j,j,
        j,j,j,j,j,j
    };
    float jX = 0; float jY = 0; int jT = 0; std::string jP;  int jCount = 0; 
    while (jfile >> jX >> jY >> jT>> jP) {
        sp = calcBlock(10.0f, 10.0f, jX * 10.0f, jY * 10.0f, scale);
        Junction tempJunction(sp.size, sp.position,jP, jT,jCount);
        Junctions[jCount] = tempJunction;
        jCount++;
    }
    jfile.close();

    // loads walls from file
    std::ifstream wfile("walls.txt");
    Wall w(sf::Vector2f(0, 0), sf::Vector2f(0, 0), 0,0);
    Wall Walls[] = {
        w,w,w,w,w,w,w,w,w,w,
        w,w,w,w,w,w,w,w,w,w,
        w,w,w,w,w,w,w,w,w,w,
        w,w,w,w,w,w,w,w,w,w,
        w,w,w,w,w,w,w,w,w,w,
        w,w,w,w,w,w,w,w,w,w
    };
    int wW = 0; int wH = 0; int wX = 0; int wY = 0; int wCount = 0; // total walls
    while (wfile >> wW >> wH >> wX >> wY) {
        sp = calcBlock(wW * 10.0f, wH * 10.0f, wX * 10.0f, wY * 10.0f, scale);
        Wall tempWall(sp.size, sp.position, 0,wCount+1);
        Walls[wCount] = tempWall;
        wCount++;
    }
    wfile.close();

    // loads pellets from file
    std::ifstream pfile("pellets.txt");
    Pellet p(sf::Vector2f(0, 0), sf::Vector2f(0, 0),1,false);
    Pellet Pellets[] = { 
        p,p,p,p,p,p,p,p,p,p,
        p,p,p,p,p,p,p,p,p,p,
        p,p,p,p,p,p,p,p,p,p,
        p,p,p,p,p,p,p,p,p,p,
        p,p,p,p,p,p,p,p,p,p,
        p,p,p,p,p,p,p,p,p,p,
        p,p,p,p,p,p,p,p,p,p,
        p,p,p,p,p,p,p,p,p,p,
        p,p,p,p,p,p,p,p,p,p,
        p,p,p,p,p,p,p,p,p,p,
        p,p,p,p,p,p,p,p,p,p,
        p,p,p,p,p,p,p,p,p,p,
        p,p,p,p,p,p,p,p,p,p,
        p,p,p,p,p,p,p,p,p,p,
        p,p,p,p,p,p,p,p,p,p,
        p,p,p,p,p,p,p,p,p,p,
        p,p,p,p,p,p,p,p,p,p,
        p,p,p,p,p,p,p,p,p,p,
        p,p,p,p,p,p,p,p,p,p,
        p,p,p,p,p,p,p,p,p,p,
        p,p,p,p,p,p,p,p,p,p,
        p,p,p,p,p,p,p,p,p,p,
        p,p,p,p,p,p,p,p,p,p,
        p,p,p,p,p,p,p,p,p,p

    };
    Pellet BigPellets[] = { p,p,p,p };
    int pX = 0; int pY = 0; int pCount = 0; // total small pellets
    while (pfile >> pX >> pY) {
        sp = calcBlock(2.5f, 2.5f, (pX * 10.0f)+3.75f, (pY * 10.0f) + 3.75f, scale);
        Pellet tempPellet(sp.size, sp.position, pCount, false);
        Pellets[pCount] = tempPellet;
        pCount++;
    }
    pfile.close();
    
    // unique objects
    sp = calcBlock(20.0f, 5.0f, 130.0f, 120.0f, scale); Wall ghostDoor(sp.size, sp.position, 0,0);
    sp = calcBlock(10.0f, 10.0f, -20.0f, 140.0f, scale); Wall tunnelLeft(sp.size, sp.position, 1,0);
    sp = calcBlock(10.0f, 10.0f, 290.0f, 140.0f, scale); Wall tunnelRight(sp.size, sp.position, 1,0);
    sp = calcBlock(30.0f, 10.0f, -10.0f, 140.0f, scale); Wall shadeLeft(sp.size, sp.position, 4, 0);
    sp = calcBlock(30.0f, 10.0f, 270.0f, 140.0f, scale); Wall shadeRight(sp.size, sp.position, 4, 0);
    
    int bPCount = 0; // total big pellets

    // creates the 4 big pellets
    sp = calcBlock(5.0f, 5.0f, 10.0f + 2.5f, 30.0f + 2.5f, scale);
    Pellet temp1(sp.size, sp.position, bPCount, false);
    BigPellets[0] = temp1; bPCount++;

    sp = calcBlock(5.0f, 5.0f, 260.0f + 2.5f, 30.0f + 2.5f, scale);
    Pellet temp2(sp.size, sp.position, bPCount, false);
    BigPellets[1] = temp2; bPCount++;

    sp = calcBlock(5.0f, 5.0f, 10.0f + 2.5f, 230.0f + 2.5f, scale);
    Pellet temp3(sp.size, sp.position, bPCount, false);
    BigPellets[2] = temp3; bPCount++;

    sp = calcBlock(5.0f, 5.0f, 260.0f + 2.5f, 230.0f + 2.5f, scale);
    Pellet temp4(sp.size, sp.position, bPCount, false);
    BigPellets[3] = temp4; bPCount++;

    int pelletsLeft = pCount + bPCount; // total pellets




    ///// MAIN PROGRAM SECTION /////



    // Main program Loop
    while (window.isOpen())
    {
        deltaTime = clock.restart().asSeconds();
        sf::Event event;
        while (window.pollEvent(event))
        {
            switch (event.type)
            {
            case sf::Event::Closed:
                window.close();
                break;

            case sf::Event::Resized:
                //resizeView(window, view);
                break;
            }
        }

        // QoL keyboard close
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape)) {
            window.close();
            return 0;
        }

        // let game begin by hitting enter key
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Enter) && !gameBegin && !gameEnd) {
            gameBegin = true;
            allowClear = true;
            player1.fsmState0();
            player1.ai(Pellets, pCount, BigPellets, bPCount, GhostGroup1, activeGhosts);
            //debug = true;
        }

        // let game reset by hitting backspace key
        // once enter key is pressed, game can be played again
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::BackSpace) && allowClear) {

            // stop game
            gameBegin = false;
            gameEnd = false;

            pelletsLeft = pCount + bPCount;
            bPCount = 4;

            // reset player
            player1.score = 0;
            player1.timer = 0.0f;
            player1.life = 100;
            player1.countdownTimer = 6.0f;
            player1.fsmState0();
            countDown = false;

            // Reset pellets
            for (int i = 0; i < pCount; i++) {
                if (Pellets[i].getEaten()) {
                    Pellets[i].setEaten(false);

                }
                Pellets[i].Draw(window);
            }

            // Reset big pellets
            for (int i = 0; i < 4; i++) {
                if (BigPellets[i].getEaten()) {
                    BigPellets[i].setEaten(false);
                }
                BigPellets[i].Draw(window);
            }

            // reset ghosts
            activeGhosts = 2;
            GhostGroup1[0].setPosition(sf::Vector2f(320.0f, 270.0f));
            GhostGroup1[1].setPosition(sf::Vector2f(320.0f, 330.0f));
            GhostGroup1[2].setPosition(sf::Vector2f(290.0f, 330.0f));
            GhostGroup1[3].setPosition(sf::Vector2f(350.0f, 330.0f));
            limitSwap = false;
            timeScript = 0;
            swapMode = false;

            for (int i = 0; i < 3; i++) {
                ghostJuncID[i] = 0;
                GhostGroup1[i].direction = 0;
                GhostGroup1[i].ghostFrighten = false;
                GhostGroup1[i].setColour();
                GhostGroup1[i].speed = 51.0f;
                GhostGroup1[i].ghostMode = 1;
            }

            // makes it so that this if statement only runs once
            allowClear = false;
        }

        // update the player stats
        std::string preSnip = std::to_string(player1.timer);
        std::string delimiter = "."; int snipper = preSnip.find(delimiter) + 3;
        std::string postSnip = preSnip.substr(0, snipper);

        p1Life2.setString(std::to_string(player1.life));
        p1Timer2.setString(postSnip);
        p1Score2.setString(std::to_string(player1.score));

        // if player wins
        if (pelletsLeft == 0 && !gameEnd) {
            printf("YOU WIN | ");
            printf("Lives: %i | Score: %i | Time: %f\n", player1.life, player1.score, player1.timer);
            gameBegin = false;
            gameEnd = true;
        }

        // if player loses
        if (player1.life == 0 && !gameEnd) {
            printf("YOU LOSE | ");
            printf("Player Score: %i | Time: %f\n", player1.score, player1.timer);
            gameBegin = false;
            gameEnd = true;
        }

        // game loop
        if (gameBegin) {

            // update timer for the frame
            player1.timer += deltaTime;

            // timer for when a big pellet has been eaten
            if (countDown) {

                // trigger once per countdown
                if (player1.countdownTimer == 6.0f) {

                    // ghost ghost colour/behaviour change
                    for (int i = 0; i < activeGhosts; i++) {

                        GhostGroup1[i].speed = 25.5f;
                        GhostGroup1[i].ghostFrighten = true;
                        GhostGroup1[i].setColour();
                        ghostJuncID[i] = 0;

                        // when first triggered, ghosts must immediatly reverse
                        int tempDirection = GhostGroup1[i].direction;

                        switch (tempDirection) {
                        case 1: tempDirection = 3; break;
                        case 2: tempDirection = 4; break;
                        case 3: tempDirection = 1; break;
                        case 4: tempDirection = 2; break;
                        }

                        GhostGroup1[i].direction = tempDirection;
                    }
                }


                //timer range from 6 seconds to 0;
                player1.countdownTimer -= deltaTime;
                player1.countdownTimer = std::max(player1.countdownTimer, 0.0f);
                limitSwap = true;

                // when timer hits 0
                if (player1.countdownTimer == 0.0f) {
                    countDown = false;
                    limitSwap = false;
                    player1.countdownTimer = 6.0f;

                    // undo ghost colour/behaviour change
                    for (int i = 0; i < activeGhosts; i++) {
                        GhostGroup1[i].ghostFrighten = false;
                        GhostGroup1[i].setColour();
                        GhostGroup1[i].speed = 51.0f;
                    }
                }
            }

            // time based system for swapping ghost modes
            if (!limitSwap) {

                switch (timeScript) {
                case 0:
                    // scatter for 7s, change to chase
                    if (player1.timer > 7.0f) {
                        timeScript = 1;
                        swapMode = true;
                    }
                    break;
                case 1:
                    // chase for 20s, change to scatter
                    if (player1.timer > 27.0f) {
                        timeScript = 2;
                        swapMode = true;
                    }
                    break;
                case 2:
                    // scatter for 7s, change to chase
                    if (player1.timer > 34.0f) {
                        timeScript = 3;
                        swapMode = true;
                    }
                    break;
                case 3:
                    // chase for 20s, change to scatter
                    if (player1.timer > 54.0f) {
                        timeScript = 4;
                        swapMode = true;
                    }
                    break;
                case 4:
                    // scatter for 5s, change to chase
                    if (player1.timer > 59.0f) {
                        timeScript = 5;
                        swapMode = true;
                    }
                    break;
                case 5:
                    // chase for 20s, change to scatter
                    if (player1.timer > 79.0f) {
                        timeScript = 6;
                        swapMode = true;
                    }
                    break;
                case 6:
                    // scatter for 5s, change to chase
                    if (player1.timer > 84.0f) {
                        limitSwap = true;
                        swapMode = true;
                        timeScript = 7;
                        //printf("Chasing Forever");
                    }
                    break;

                }
            }

            // if swapMode = true, toggles all ghosts modes between scatter and chase
            if (swapMode) {

                int mode = 0;
                // FIX: change < activeGhosts to 3, causing issues with blue/orange being potentially opp mode of expected
                for (int i = 0; i < activeGhosts; i++) {
                    mode = GhostGroup1[i].ghostMode;

                    if (mode == 1) {
                        mode = 2;
                    }
                    else {
                        mode = 1;
                    }
                    GhostGroup1[i].ghostMode = mode;
                }
                //+printf("Ghost mode now: %i\n",mode);
                swapMode = false;
            }

            // release Blue
            if (pelletsLeft == pCount - 30 && !limitGhostCheck) {
                //printf("Release Ghost 3\n");
                activeGhosts = 3;
                limitGhostCheck = true;
            }

            // release orange
            if (pelletsLeft == 161 && limitGhostCheck) {
                //printf("Release Ghost 4\n");
                activeGhosts = 4;
                limitGhostCheck = false;
            }

            // applies movements to all objects
            player1.applyMovement(deltaTime);
            for (int i = 0; i < activeGhosts; i++) {
                GhostGroup1[i].applyMovement(deltaTime);
            }






            ///// COLLISION SECTION /////




            // collision between player and pellet
            bool isCollision = false;
            for (int i = 0; i < pCount; i++) {
                isCollision = Pellets[i].getCollider().checkCollision(player1.getCollider(), 1.0f, 3);

                // if pellet collision and already hasn't been eaten, eat
                if (isCollision == true && Pellets[i].getEaten() == false) {
                    Pellets[i].setEaten(true);
                    player1.score += 10;
                    pelletsLeft--;
                    isCollision = false;
                }
            }

            // collision between player and big pellet
            for (int i = 0; i < bPCount; i++) {
                isCollision = BigPellets[i].getCollider().checkCollision(player1.getCollider(), 1.0f, 3);

                // if pellet collision and already hasn't been eaten, eat
                if (isCollision == true && BigPellets[i].getEaten() == false) {
                    BigPellets[i].setEaten(true);
                    player1.score += 50;
                    pelletsLeft--;
                    isCollision = false;
                    countDown = true;
                }
            }

            // prints player score to console whil not in debug
            if (!debug) {
                //printf("\rPlayer Score: %i ", p1Score); fflush(stdout);
            }

            // collision between player/ghost and tunnel teleport
            tunnelLeft.getCollider().checkCollision(player1.getCollider(), 1.0f, 1);
            tunnelRight.getCollider().checkCollision(player1.getCollider(), 1.0f, 2);
            for (int i = 0; i < activeGhosts; i++) {
                tunnelLeft.getCollider().checkCollision(GhostGroup1[i].getCollider(), 1.0f, 1);
                tunnelRight.getCollider().checkCollision(GhostGroup1[i].getCollider(), 1.0f, 2);
            }


            // collision with junctions, sets position for next frame
            for (int i = 0; i < jCount; i++) {

                // jCheck = true if colliding AND cores are within range
                jCheck = Junctions[i].getCollider().checkCollision(player1.getCollider(), 1.0f, 3);

                // limits junction interaction to once
                if (jCheck && Junctions[i].returnID() != player1.junctionID && Junctions[i].returnType() != 5) {

                    // set player position to junction then apply decision making
                    player1.setJunction(Junctions[i].getPosition(), i, Junctions[i].getPath());
                    player1.ai(Pellets, pCount, BigPellets, bPCount, GhostGroup1, activeGhosts);

                }
            }


            // wall collision

            // for every wall
            for (int i = 0; i < wCount; i++) {

                // check for player collision
                Walls[i].getCollider().checkCollision(player1.getCollider(), 1.0f, 0);

                // for every chost
                for (int j = 0; j < activeGhosts; j++) {

                    // check for ghost collision
                    Walls[i].getCollider().checkCollision(GhostGroup1[j].getCollider(), 1.0f, 0);
                }
            }

            // if a player has stopped, allow movement next frame
            if (player1.getPosition() == player1.junctionCore) {
                allowChange = true;
            }

            // collision between ghost and junction
            std::string ghostJunctionPath = "----";
            for (int i = 0; i < activeGhosts; i++) {
                ghostJuncTouch[i] = false;
            }

            // for every junction
            for (int i = 0; i < jCount; i++) {

                // jCheck = true if colliding AND cores are within range
                ghostJuncTouch[0] = Junctions[i].getCollider().checkCollision(GhostGroup1[0].getCollider(), 1.0f, 4);
                ghostJuncTouch[1] = Junctions[i].getCollider().checkCollision(GhostGroup1[1].getCollider(), 1.0f, 4);
                ghostJuncTouch[2] = Junctions[i].getCollider().checkCollision(GhostGroup1[2].getCollider(), 1.0f, 4);
                ghostJuncTouch[3] = Junctions[i].getCollider().checkCollision(GhostGroup1[3].getCollider(), 1.0f, 4);

                // for every ghost
                for (int j = 0; j < activeGhosts; j++) {

                    // if touching for the first time
                    if (ghostJuncTouch[j] && Junctions[i].returnID() != ghostJuncID[j]) {
                        //printf("beep Test\n");

                        // ghosts are only allowed to get a new target when they hit a certain type of junction
                        sf::Vector2f Target = player1.getPosition();
                        ghostJuncID[j] = Junctions[i].returnID();
                        GhostGroup1[j].setPosition(Junctions[i].getPosition());

                        // if allowed new target
                        if (Junctions[i].returnType() != 4) {

                            // calcs new direction based on where player currently is and where they are facing
                            GhostGroup1[j].calcDirection(Target, player1.direction, GhostGroup1[0].getPosition(), Junctions[i].getPath(), Junctions[i].returnType());

                            // set ghost memory of target info
                            ghostMemory[j] = Target;
                            gdm[j] = player1.direction;
                        }

                        // else use target stored in memory
                        else {
                            GhostGroup1[j].calcDirection(ghostMemory[j], gdm[j], GhostGroup1[0].getPosition(), Junctions[i].getPath(), Junctions[i].returnType());
                        }

                        // move
                        GhostGroup1[j].applyMovement(deltaTime);

                        // used to track ghost junction options
                        if (debug && j == 0) {
                            std::cout << "Ghost: " << GhostGroup1[j].ghostID << " | Junction " << i << " Options: " << Junctions[i].getPath() << std::endl;
                        }
                    }
                }
            }

            // collision between ghost and player

            // for every ghost
            for (int i = 0; i < activeGhosts; i++) {
                bool test = player1.getCollider().checkCollision(GhostGroup1[i].getCollider(), 1.0f, 4);

                // if collision
                if (test && !damage) {

                    // take damage
                    if (!countDown) {
                        //

                        //player1.life -= 1;
                        damage = true;
                        // reset player position
                        player1.setJunction(Junctions[64].getPosition(), 64, Junctions[64].getPath());
                        player1.setPosition(player1.junctionCore);
                        //player1.direction = 0;
                        player1.fsmState5();
                        player1.ai(Pellets, pCount, BigPellets, bPCount, GhostGroup1, activeGhosts);

                    }

                    // eat ghost
                    else {

                        // reset ghost
                        ghostJuncID[i] = 0;
                        GhostGroup1[i].direction = 0;
                        GhostGroup1[i].ghostFrighten = false;
                        GhostGroup1[i].setColour();
                        player1.score += 100;
                        GhostGroup1[i].speed = 51.0f;
                        // reset ghost pos
                        switch (i) {
                        case 0: GhostGroup1[0].setPosition(sf::Vector2f(320.0f, 270.0f)); break;
                        case 1: GhostGroup1[1].setPosition(sf::Vector2f(320.0f, 330.0f)); break;
                        case 2: GhostGroup1[2].setPosition(sf::Vector2f(290.0f, 330.0f)); break;
                        case 3: GhostGroup1[3].setPosition(sf::Vector2f(350.0f, 330.0f)); break;
                        }

                    }
                }
            }

            // 4 seconds of immunity after being hit
            if (damage) {
                iframes -= deltaTime;
                if (iframes <= 0.0f) {
                    damage = false;
                    iframes = 4.0f;
                }
            }

        }





        ///// RENDER SECTION /////




            //view.setCenter(player1.getPosition());
        window.clear();
        //window.setView(view);


        // Draws walls apart from parts of the tunnel
        for (int i = 0; i < wCount - 4; i++) {
            Walls[i].Draw(window);
        }
        ghostDoor.Draw(window);


        // draw debug items;
        if (debug) {

            // Draws all junctions
            for (int i = 0; i < jCount; i++) {
                if (debug && Junctions[i].returnType() != 5) {
                    Junctions[i].Draw(window);
                }
            }

            // draws tunnel
            tunnelLeft.Draw(window);
            tunnelRight.Draw(window);
            for (int i = std::max(wCount - 4, 0); i < wCount; i++) {
                Walls[i].Draw(window);
            }
        }

        // draw normally
        else {

            // draw uneaten pellets
            for (int i = 0; i < pCount; i++) {
                if (!Pellets[i].getEaten()) {
                    Pellets[i].Draw(window);
                }
            }

            // draw uneaten big pellets
            for (int i = 0; i < 4; i++) {
                if (!BigPellets[i].getEaten()) {
                    BigPellets[i].Draw(window);
                }
            }
        }

        // draw player stats
        if (!debug) {
            window.draw(p1Life1); window.draw(p1Life2);
            window.draw(p1Score1); window.draw(p1Score2);
            window.draw(p1Timer1); window.draw(p1Timer2);
        }

        // draw player/ghosts
        if(player1.life != 0) {
            player1.Draw(window);
        }

        for (int i = 0; i < 4; i++) {
            GhostGroup1[i].Draw(window);
        }

        // drawn last so that it covers up everything "beneath" it
        // draw shade? idk what to call it
        if (!debug) {
            shadeLeft.Draw(window);
            shadeRight.Draw(window);
        }

        // draw window
        window.display();
    }
        return 0;
}


