#pragma once
#include <SFML\Graphics.hpp>
#include "Collider.h"
class Pellet
{
public:
	Pellet(sf::Vector2f size, sf::Vector2f position, int pelletID, bool eaten);
	~Pellet();
	bool eaten;
	int pelletID;
	void Draw(sf::RenderWindow& window);
	Collider getCollider() { return Collider(body); }
	bool getEaten() { return eaten;	}
	void setEaten(bool choice) { eaten = choice; }
	sf::Vector2f getPosition() { return body.getPosition(); }
private:
	sf::RectangleShape body;

	
};

