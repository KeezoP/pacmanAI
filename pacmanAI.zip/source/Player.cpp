#include "Player.h"

Player::Player(float speed, sf::Vector2f spawn)
{
	float scale = 2;
	float offset = 20;
	float xVal = (spawn.x + offset) * scale;
	float yVal = (spawn.y + offset) * scale;

	this->speed = speed;
	this->fsmState = 0;
	this->junctionCore = sf::Vector2f(0.0f, 0.0f);
	this->junctionPath = "----";
	this->junctionID = 0;
	this->score = 0;
	this->timer = 0.0f;
	this->countdownTimer = 6.0f;
	this->spawnPos = sf::Vector2f(xVal,yVal);

	body.setSize(sf::Vector2f(10.0f*scale, 10.0f*scale));
	body.setOrigin(body.getSize() / 2.0f);
	body.setFillColor(sf::Color::Yellow);
	body.setPosition(xVal, yVal);
	
}

Player::~Player()
{

}

void Player::ai(Pellet Pellets[],int pCount,Pellet BigPellets[],int bPCount, Ghost GhostGroup1[],int activeGhosts) {

	// This is the actual assignment part

	/*
		FSM
		
		pac man has 6 planned states:
			State 0: Spawning
			State 1: Search for nearest small pellet
			State 2: Search for nearest big pellet
			State 3: Search for nearest ghost
			State 4: Run from nearest ghost
			State 5: Die	
	*/

	int ghostCheck;
	float closestGhost= 100000.0f;
	float closestBigPellet = 100000.0f;
	int cBPID = 10;
	float tempDistance;
	sf::Vector2f tempPos = getPosition();
	float tempDirection = 0;


	if (countdownTimer < 6.0f && countdownTimer > 1.0f) {
		fsmState = 3;
	}
	
	switch (fsmState) {
	
	case 0: 
		
		fsmState0(); // spawn state
		break;

	case 1:

		// check for any nearby ghosts
		ghostCheck = ghostsInRange(GhostGroup1, activeGhosts);

		// if no nearby ghosts, eat small pellets
		if (ghostCheck == 10) {
			fsmState1(Pellets,pCount);
		}

		// else check for nearby big pellets
		else {
			fsmState = 2;
			fsmState2(BigPellets, bPCount);
		}
		break;

	case 2:

		// check for any nearby ghosts
		ghostCheck = ghostsInRange(GhostGroup1, activeGhosts);
		
		// if no nearby ghosts, eat small pellets
		if (ghostCheck == 10) {
			fsmState = 1;
			fsmState1(Pellets, pCount);
		}
		
		// else if ghosts in range, decide whether to go for big pellet or run
		else {

			// check for closest ghost
			for (int i = 0; i < activeGhosts; i++) {
				tempDistance = calcDistance(getPosition(), GhostGroup1[i].getPosition());

				if (tempDistance < closestGhost) {
					closestGhost = tempDistance;
				}
			}

			// check for closest big pellet
			for (int i = 0; i < bPCount; i++) {
				tempDistance = calcDistance(BigPellets[i].getPosition(), getPosition());
			
				if (tempDistance < closestBigPellet && !BigPellets[i].eaten) {
					closestBigPellet = tempDistance;
					cBPID = i;
				}
			}

			// if any uneaten pellets left
			if (cBPID != 10) {
				
				// if ghost in range but pellet is closer
				if (closestBigPellet < closestGhost) {
					calcDirection(BigPellets[cBPID].getPosition());
				}
				else {

					// backup current direction
					tempDirection = direction;

					// calc direction for bp
					calcDirection(BigPellets[cBPID].getPosition());

					switch (direction) {
					case 1:
						tempPos.y -= 5.0f;
						tempDistance = calcDistance(tempPos, GhostGroup1[ghostCheck].getPosition());
						if (tempDistance > closestGhost) {
							fsmState2(BigPellets, bPCount);
						}
						else {
							fsmState = 4;
							direction = tempDirection;
							fsmState4(GhostGroup1, activeGhosts, Pellets, pCount);
						}
						break;
					case 2:
						tempPos.x += 5.0f;
						tempDistance = calcDistance(tempPos, GhostGroup1[ghostCheck].getPosition());
						if (tempDistance > closestGhost) {
							fsmState2(BigPellets, bPCount);
						}
						else {
							fsmState = 4;
							direction = tempDirection;
							fsmState4(GhostGroup1, activeGhosts, Pellets, pCount);
						}
						break;
					case 3:
						tempPos.y += 5.0f;
						tempDistance = calcDistance(tempPos, GhostGroup1[ghostCheck].getPosition());
						if (tempDistance > closestGhost) {
							fsmState2(BigPellets, bPCount);
						}
						else {
							fsmState = 4;
							direction = tempDirection;
							fsmState4(GhostGroup1, activeGhosts, Pellets, pCount);
						}
						break;
					case 4:
						tempPos.x -= 5.0f;
						tempDistance = calcDistance(tempPos, GhostGroup1[ghostCheck].getPosition());
						if (tempDistance > closestGhost) {
							fsmState2(BigPellets, bPCount);
						}
						else {
							fsmState = 4;
							direction = tempDirection;
							fsmState4(GhostGroup1, activeGhosts, Pellets, pCount);
						}
						break;
					}


				}
			}

			// no big pellets left
			else {
				fsmState4(GhostGroup1, activeGhosts, Pellets, pCount);
			}
		}

		break;

	case 3:

		// if no ghosts in range, eat small pellets
		if (ghostsInRange(GhostGroup1, activeGhosts) == 10) {
			fsmState = 1;
			fsmState1(Pellets, pCount);
		}
		else {

			// if not enough time left, run from ghost
			if (countdownTimer < 1.0f) {
				fsmState = 4;
				fsmState4(GhostGroup1, activeGhosts, Pellets, pCount);
			}
			else {
				// go eat a ghost
				fsmState3(GhostGroup1, activeGhosts, Pellets, pCount);
			}
			break;
		}


		
	
	case 4: 
		// run from ghost
		fsmState4(GhostGroup1,activeGhosts, Pellets, pCount);
	}
}

void Player::fsmState0() {
	// state: spawn pac man		
	// reset player position
	body.setPosition(spawnPos); // set position
	direction = 0; // where pac man is facing, 1 2 3 4 : wdsa (clockwise rotation)
	fsmState = 1;

	// reset junction memory
	junctionCore = sf::Vector2f(320.0f, 510.0f); // used to help turning
	junctionPath = "-a-d"; // used to calc legal path choices
	junctionID = 0;
}

void Player::fsmState1(Pellet Pellets[], int pCount) {
	// state 1: find nearest small pellet
	
	/*
		searches Pellets[] to find the closest pellet
		due to the design of Pellets[],
		assuming 4 pellets are in equal caridnal directions
		priority will be: above, left, right, below
	*/

	int pelletTarget = getClosestPellet(Pellets, pCount);

	// calc legal direction that will bring me closest
	calcDirection(Pellets[pelletTarget].getPosition());
}

void Player::fsmState2(Pellet BigPellets[], int bPCount) {
	// state 2: find nearest big pellet 
	// searches BigPellets[] to find the closest pellet
	
	float distance = 100000.0f;
	int pelletTarget = 0;
	float tempDistance;

	// for every uneaten big pellet
	int counter = 0;

	for (int i = 0; i < bPCount; i++) {
		if (!BigPellets[i].getEaten()) {
			counter++;

			// calc distance
			tempDistance = calcDistance(BigPellets[i].getPosition(),getPosition());

			// check if closest
			if (tempDistance < distance) {

				distance = tempDistance;
				pelletTarget = i;
			}
		}
	}
	// calc legal direction that will bring me closest
	calcDirection(BigPellets[pelletTarget].getPosition());
	}

void Player::fsmState3(Ghost Ghosts[], int activeGhosts, Pellet Pellets[], int pCount) {
	// state 3: find nearest ghost
	// searches Ghosts[] to find the closest ghost

	float distance = 100000.0f;
	int ghostTarget = 0;
	
	int ghostID = ghostsInRange(Ghosts, activeGhosts);

	// if ghost in range
	if (ghostID != 10) {
		
		// check if ghost is frightened
		if (Ghosts[ghostID].ghostFrighten) {
			// calc legal direction that will bring me closest
			calcDirection(Ghosts[ghostTarget].getPosition());
		}
		else {
			fsmState = 4;
			fsmState4(Ghosts,activeGhosts, Pellets, pCount);
		}
	}
	// return to eating smallPellets
	else {
		fsmState = 1;
		fsmState1(Pellets, pCount);
	}
}

void Player::fsmState4(Ghost Ghosts[], int activeGhosts, Pellet Pellets[], int pCount) {
	// state 4: best path to run from ghosts
	
	int closestGhost;

	// find closest ghost in range
	closestGhost = ghostsInRange(Ghosts, activeGhosts);

	if (closestGhost == 10) {
		fsmState = 1;
		fsmState1(Pellets, pCount);
	}
	else {
		// calc legal direction that gets me furthest
		calcRunToDirection(Ghosts[closestGhost].getPosition(),Ghosts[closestGhost].direction, Pellets, pCount);
	}	
}

void Player::fsmState5() {
	// state 5: dying
	
	if (life > 0) {
		this->life -= 1;
		this->score  = std::max(0,score -=100);
		this->fsmState = 0;
		fsmState0();
	}
	else {
		printf("fsmDeath\n");
	}
}

void Player::calcDirection(sf::Vector2f targetPos) {
	/*
		i want to allow reversing but 
		the decision making/path finding doesn't handle it well

		if reversing is allowed it can get stuck 
		in a constant state of reverse reverse

		as all distance based decisions are "as the crow flies"
		it doesn't take into account walls, or the length of the path
		that it would have to take to get there
	*/

	sf::Vector2f shift = getPosition();
	float check;
	float shortestPath = 100000.0f;
	int tempDirection = direction;
	int newDirection = 0;
	
	// if up is a legal path
	if (junctionPath.find("w") != std::string::npos && direction != 3) {

		shift.y -= 10.0f;
		check = calcDistance(targetPos,shift);
		
		//check if direction reduces distance
		if (check < shortestPath && check > 2) {
			shortestPath = check;
			newDirection = 1;
		}
		shift.y += 10.0f;
	}

	// if left is a legal path
	if (junctionPath.find("a") != std::string::npos && direction != 2) {

		shift.x -= 10.0f;
		check = calcDistance(targetPos,shift);
		
		//check if direction reduces distance
		if (check < shortestPath && check > 2) {
			shortestPath = check;
			newDirection = 4;
		}
		shift.x += 10.0f;
	}

	// if down is a legal path
	if (junctionPath.find("s") != std::string::npos && direction != 1) {

		shift.y += 10.0f;
		check = calcDistance(targetPos,shift);

		//check if direction reduces distance
		if (check < shortestPath && check > 2) {
			shortestPath = check;
			newDirection = 3;
		}
		shift.y -= 10.0f;
	}

	// if right is a legal path
	if (junctionPath.find("d") != std::string::npos && direction != 4) {

		shift.x += 10.0f;
		check = calcDistance(targetPos,shift);

		//check if direction reduces distance
		if (check < shortestPath && check > 2) {
			shortestPath = check;
			newDirection = 2;
		}
		shift.x -= 10.0f;
	}


	if (newDirection == 0) {
		newDirection = tempDirection;
	}
	direction = newDirection;
}

void Player::calcRunToDirection(sf::Vector2f targetPos, int ghostDirection,Pellet pellets[], int pCount) {

	sf::Vector2f shift = getPosition();
	float check;
	float largestPath = 0.0f;
	float paths[4];
	int pelletID;
	int newDirection = direction;
	bool legalTurn[4];
	bool choices = false;

	// check all legal paths for escape options
	
	// if up is a legal path
	if (junctionPath.find("w") != std::string::npos) {

		shift.y -= 5.0f;
		// calc distance between closest ghost and player shifted pos
		check = calcDistance(targetPos, shift);
		//printf("W: %f\n",check);
		//check if direction increases distance
		if (check > largestPath) {
			largestPath = check;
			paths[0] = check;
			legalTurn[0] = true;
			newDirection = 1;
		}
		shift.y += 5.0f;
	}

	// if left is a legal path
	if (junctionPath.find("a") != std::string::npos) {

		shift.x -= 5.0f;
		check = calcDistance(targetPos, shift);
		//printf("A: %f\n", check);
		//check if direction increases distance
		if (check > largestPath) {
			largestPath = check;
			paths[3] = check;
			legalTurn[3] = true;
			newDirection = 4;
		}
		shift.x += 5.0f;
	}

	// if down is a legal path
	if (junctionPath.find("s") != std::string::npos) {

		shift.y += 5.0f;
		check = calcDistance(targetPos, shift);
		//printf("S: %f\n", check);
		//check if direction increases distance
		if (check > largestPath) {
			largestPath = check;
			paths[2] = check;
			legalTurn[2] = true;
			newDirection = 3;
		}
		shift.y -= 5.0f;
	}

	// if right is a legal path
	if (junctionPath.find("d") != std::string::npos) {

		shift.x += 5.0f;
		check = calcDistance(targetPos, shift);
		//printf("D: %f\n", check);
		//check if direction increases distance
		if (check > largestPath) {
			largestPath = check;
			paths[1] = check;
			legalTurn[1] = true;
			newDirection = 2;
		}
		shift.x -= 5.0f;
	}

	// calc the distance between nearest pellet and player
	pelletID = getClosestPellet(pellets, pCount);
	//pelletPath = calcDistance(pellets[pelletID].getPosition(), getPosition());
	sf::Vector2f pelletPos = pellets[pelletID].getPosition();

	// new Direction stores best non pellet path;

	// temp calc direction for nearest pellet
	calcDirection(pelletPos);
	int pelletDirection = direction;
	bool pelletPath = false;
	// for all paths
	for (int i = 0; i < 4; i++) {

		// if path = to largest
		if (paths[i] == largestPath) {
			choices = true;
			//printf("Largest Path: %i\n",i+1);
		}

		// or if path is close enough to largest
		if (paths[i] != largestPath && paths[i] > 0.0f) {
			if (largestPath - paths[i] < 1.0f) {
				choices = true;
			}
		}

		if (choices && !pelletPath && legalTurn[i]) {
			//printf("Possible pellet path : %i\n", i + 1);
			// check if path matches pellet direction
			switch (i) {
			case 0:
				if (pelletDirection == 1) {
					pelletPath = true;
				}
				break;
			case 1:
				if (pelletDirection == 2) {
					pelletPath = true;
				}
				break;
			case 2:
				if (pelletDirection == 3) {
					pelletPath = true;
				}
				break;
			case 3:
				if (pelletDirection == 4) {
					pelletPath = true;
				}
				break;
			}

		}


	}

	if (pelletPath) {
		//printf("Pellet direction: %i\n",pelletDirection);
		direction = pelletDirection;
	}
	else {
		//printf("Path direction: %i\n", newDirection);
		direction = newDirection;
	}
	
	//printf("Turn: %i\n",newDirection);
	//printf("\n");
}

int Player::getClosestPellet(Pellet Pellets[], int pCount) {
	float distance = 100000.0f;
	int pelletTarget = 0;
	float tempDistance;
	// for every uneaten pellet
	for (int i = 0; i < pCount; i++) {
		if (!Pellets[i].getEaten()) {

			// calc distance
			tempDistance = calcDistance(Pellets[i].getPosition(), getPosition());

			// check if closest
			if (tempDistance < distance) {

				distance = tempDistance;
				pelletTarget = i;
			}
		}
	}

	return pelletTarget;
}

float Player::calcDistance(sf::Vector2f target, sf::Vector2f shift) { 

	// calc distance
	float xVal = target.x - shift.x;
	float yVal = target.y - shift.y;
	float total = sqrt((xVal * xVal) + (yVal * yVal));
	//printf("Total: %f\n", total);
	return total;
}

int Player::ghostsInRange(Ghost Ghosts[], int activeGhosts) {
	
	float tempDistance = 1000000.0f;
	float range = 5.0f;
	int result = 10;
	float closest = 1000000.0f;
	//printf("Check\n");
	// for every active ghost
	for (int i = 0; i < activeGhosts; i++) {
		tempDistance = calcDistance(Ghosts[i].getPosition(), getPosition()) / 20;
	
		// check if in range
		if (tempDistance < range && tempDistance < closest) {
			closest = tempDistance;
			result = i;
			//printf("ActiveGhosts: %i\n",activeGhosts);
			//printf(" Ghost : %i | Distance : %f\n", result, closest);
		}
	}
	if (result != 10) {
		//printf("Closest : %i \n", result);
	}
	return result;
}

void Player::applyMovement(float deltaTime)
{
	//applies constant movement based on direction
	sf::Vector2f movement(0.0f, 0.0f);

		switch (direction) {
		case 1:
			movement.y -= speed * deltaTime;
			break;

		case 2:
			movement.x += speed * deltaTime;
			break;

		case 3:
			movement.y += speed * deltaTime;
			break;

		case 4:
			movement.x -= speed * deltaTime;
			break;
		}
		body.move(movement);
}

void Player::Draw(sf::RenderWindow& window)
{
	window.draw(body);
}

void Player::userInput() {


	if (sf::Keyboard::isKeyPressed(sf::Keyboard::A)) {
		direction = 4;
	}
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::D)) {
		direction = 2;
	}
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::W)) {
		direction = 1;
	}
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::S)) {
		direction = 3;
	}
}

void Player::setPosition(sf::Vector2f newPos) {
	body.setPosition(newPos);
}

void Player::setJunction(sf::Vector2f jCore, int jID, std::string jPath) {
	this->junctionCore = jCore;
	this->junctionID = jID;
	this->junctionPath = jPath;
}