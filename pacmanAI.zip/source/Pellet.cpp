#include "Pellet.h"

Pellet::Pellet(sf::Vector2f size, sf::Vector2f position, int pID, bool isEaten)
{
	body.setFillColor(sf::Color::White);
	body.setSize(size);
	body.setOrigin(size / 2.0f);
	body.setPosition(position);
	pelletID = pID;
	eaten = isEaten;
}

Pellet::~Pellet()
{

}

void Pellet::Draw(sf::RenderWindow& window)
{
	window.draw(body);
}


