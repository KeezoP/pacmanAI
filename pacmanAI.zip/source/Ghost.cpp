#include "Ghost.h"



Ghost::Ghost(int ID, sf::Vector2f Pos)
{
	this->ghostID = ID;
	
	/*
	ghostMode:
		0 none
		1 scatter
	2 chase
	*/

	this->ghostMode = 1;

	float scale = 2;
	float offset = 20;
	this->speed = 51.0f;
	this->ghostFrighten = false;

	setColour();

	body.setSize(sf::Vector2f(10.0f * scale, 10.0f * scale));
	body.setOrigin(body.getSize() / 2.0f);

	float xVal = (Pos.x + offset) * scale;
	float yVal = (Pos.y + offset) * scale;

	body.setPosition(xVal, yVal);
}

Ghost::~Ghost()
{
}

void Ghost::setColour() {
	if (!ghostFrighten) {
		switch (ghostID) {
		case 1:
			body.setFillColor(sf::Color::Red);
			break;
		case 2:
			body.setFillColor(sf::Color::Magenta);
			break;
		case 3:
			body.setFillColor(sf::Color::Cyan);
			break;
		case 4:
			body.setFillColor(sf::Color::Color(249, 180, 45, 255));
			break;
		}
	}
	else {
		body.setFillColor(sf::Color::Blue);
	}
	
}

void Ghost::applyMovement(float deltaTime)
{
	sf::Vector2f movement(0.0f, 0.0f);

	switch (direction) {
	case 1:
		movement.y -= speed * deltaTime;
		break;

	case 2:
		movement.x += speed * deltaTime;
		break;

	case 3:
		movement.y += speed * deltaTime;
		break;

	case 4:
		movement.x -= speed * deltaTime;
		break;
	}
	body.move(movement);
}

void Ghost::Draw(sf::RenderWindow& window)
{
	window.draw(body);
}

void Ghost::setPosition(sf::Vector2f newPos)
{
	body.setPosition(newPos);
}

void Ghost::calcDirection(sf::Vector2f playerPos, int playerDirection, sf::Vector2f redPos, std::string path, int typeID)
{
	/*
		Ghosts have 3 states, depending on their setting, depends on where they want to go
		ghostID is:
		1 red
		2 pink
		3 blue
		4 orange

		ghostMode:
		0 none
		1 scatter
		2 chase
	*/

	sf::Vector2f Target = sf::Vector2f(0.0f, 0.0f);

	// step 1, calc target
	switch (ghostMode) {
	case 1:
		// scatter
		Target = Scatter();
		break;
	case 2:
		// chase
		Target = calcTarget(playerPos, playerDirection, redPos);
		break;
	}

	if (ghostFrighten) {
		// frighten
		Target = Scatter();
	}

	/*
		step2, figure out path
		path contains all legal targets
		ghosts are not allowed to reverse, or go up at yellow junctions
	*/

	float shortestPath = 100000.0f;
	float check = 0.0f;
	int newDirection = 0;

	if (!ghostFrighten){

		sf::Vector2f shiftGhost = getPosition();
		
		if (path.find("w") != std::string::npos && direction != 3 && typeID != 3) {
			shiftGhost.y -= 20;
			check = getDistance(Target, shiftGhost);
			if (check < shortestPath) {
				shortestPath = check;
				newDirection = 1;
			}
			shiftGhost = getPosition();

		}
		if (path.find("a") != std::string::npos && direction != 2) {
			shiftGhost.x -= 20;
			//if (ghostID == 2) printf("ghost vs shift: %f -> %f\n",getPosition().x,shiftGhost.x);
			check = getDistance(Target, shiftGhost);
			if (check < shortestPath) {
				shortestPath = check;
				newDirection = 4;
			}
			shiftGhost = getPosition();
		}
		if (path.find("s") != std::string::npos && direction != 1) {
			shiftGhost.y += 20;
			check = getDistance(Target, shiftGhost);
			if (check < shortestPath) {
				shortestPath = check;
				newDirection = 3;
			}
			shiftGhost = getPosition();
	}
		if (path.find("d") != std::string::npos && direction != 4) {
		shiftGhost.x += 20;
		check = getDistance(Target, shiftGhost);
		if (check < shortestPath) {
			shortestPath = check;
			newDirection = 2;
		}
		shiftGhost = getPosition();
	}
		
		direction = newDirection;
	}

	// randomly generates a direction if in frighten mode
	if (ghostFrighten) {

		bool correctDirection = false;

		// loop until random legal direction is found
		do {
			
			//generate a random direction
			newDirection = rand() % 4 + 1;

			// test if legal
			switch (newDirection) {
			case 1:
				if (path.find("w") != std::string::npos && direction != 3 && typeID != 3) {
					direction = newDirection;
					correctDirection = true;
				}
				break;
			case 4:
				if (path.find("a") != std::string::npos && direction != 2) {
					direction = newDirection;
					correctDirection = true;
				}
				break;
			case 3:
				if (path.find("s") != std::string::npos && direction != 1) {
					direction = newDirection;
					correctDirection = true;
				}
				break;
			case 2:
				if (path.find("d") != std::string::npos && direction != 4) {
					direction = newDirection;
					correctDirection = true;
				}
				break;
			}
		
		} while (!correctDirection);
	}
}

sf::Vector2f Ghost::Scatter() {

	// when in scatter mode, ghosts will try to get to a specific tile outside maze
	float offset = 20.0f;
	float scale = 2.0f;
	float xVal = 0.0f;
	float yVal = 0.0f;

	switch (ghostID) {
	case 1: 
		xVal = 530.0f;
		yVal = 10.0f;
		break;
	case 2:
		xVal = 570.0f;
		yVal = 690.0f;
		break;
	case 3:
		xVal = 110.0f;
		yVal = 10.0f;
		break;
	case 4:
		xVal = 70.0f;
		yVal = 690.0f;
		break;


	}
	return sf::Vector2f(xVal, yVal);
}

sf::Vector2f Ghost::calcTarget(sf::Vector2f playerPos,int playerDirection,sf::Vector2f redPos) {
	
	// calc ghost target for chase
	sf::Vector2f Target = playerPos;
	float xVal = 0;
	float yVal = 0;
	float disX = 0;
	float disY = 0;
	bool inRange = false;
	sf::Vector2f tempTarget = playerPos;

	switch (ghostID) {
	case 1:
		// red ghost is simple, target is pacmans current position
		Target = playerPos;
		break;
	case 2:
		// pink ghost target is four tiles in front of pacmans direction
		// one tile is a 20 x 20 pixel block

		switch (playerDirection) {
			case 0:
				yVal -= 80.0f;
			break;

			case 1:
				yVal -= 80.0f;
			break;

			case 2:
				xVal += 80.0f;
				break;

			case 3:
				yVal += 80.0f;
				break;

			case 4:
				xVal -= 80.0f;
				break;

		}
		Target = sf::Vector2f(playerPos.x+xVal,playerPos.y+yVal);	
		break;

	case 3:
		// blue ghost target is a multi step process

		// step 1, select a spot two tiles in front of pacman
		
		switch (playerDirection) {
		case 0:
			yVal -= 40.0f;
			break;

		case 1:
			yVal -= 40.0f;
			break;

		case 2:
			xVal += 40.0f;
			break;

		case 3:
			yVal += 40.0f;
			break;

		case 4:
			xVal -= 40.0f;
			break;

		}

		tempTarget.x += xVal;
		tempTarget.y += yVal;

		// step 2, calc the x,y distance between tempTarget and red ghost location, 
		disX = tempTarget.x - redPos.x;
		disY = tempTarget.y - redPos.y;

		tempTarget.x += disX;
		tempTarget.y += disY;

		Target = tempTarget;
		break;

	case 4:
		// orange ghost target is pacman if > 8 tiles away, else scatterTarget;
		xVal = (playerPos.x - getPosition().x)/20;
		yVal = (playerPos.y - getPosition().y)/20;
		inRange = false;

		if ((getDistance(playerPos, getPosition()) / 20) < 8) {
			inRange = true;
			}
		if (!inRange) {
			Target = playerPos;
		}
		else {
			Target = Scatter();
		}
		break;
	}
	return Target;
}

float Ghost::getDistance(sf::Vector2f target, sf::Vector2f shiftedPos) {
	float dx = target.x - shiftedPos.x;
	float dy = target.y - shiftedPos.y;
	float distance = sqrt((dx * dx) + (dy * dy));
	return distance;
}