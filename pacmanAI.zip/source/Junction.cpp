#include "Junction.h"

Junction::Junction(sf::Vector2f size, sf::Vector2f position, std::string input, int colourID, int uniqueID)
{
	switch (colourID) {
	case 0:
		body.setFillColor(sf::Color::White);
		break;
	case 1:
		body.setFillColor(sf::Color::Red);
		break;
	case 2:
		body.setFillColor(sf::Color::Green);
		break;
	case 3:
		body.setFillColor(sf::Color::Yellow);
		break;
	case 4:
		body.setFillColor(sf::Color::Color(131, 131, 131, 204));
		break;
	case 5:
		body.setFillColor(sf::Color::Color(134, 134, 134, 204));
		break;
	case 6:
		body.setFillColor(sf::Color::Red);
		break;
	case 7:
		body.setFillColor(sf::Color::Cyan);
		break;
	case 8:
		body.setFillColor(sf::Color::Magenta);
		break;
	case 9:
		body.setFillColor(sf::Color::Color(249, 180, 45, 255));
		break;

	}
	typeID = colourID;

	body.setSize(size);
	body.setOrigin(size / 2.0f);
	body.setPosition(position);
	objID = uniqueID;
	path = input;
}

Junction::~Junction()
{

}

void Junction::Draw(sf::RenderWindow& window)
{
	window.draw(body);
}
