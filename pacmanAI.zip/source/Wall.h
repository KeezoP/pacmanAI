#pragma once
#include <SFML\Graphics.hpp>
#include "Collider.h"
class Wall
{
public:
	Wall(sf::Vector2f size, sf::Vector2f position, int colourID, int objID);
	~Wall();
	
	void Draw(sf::RenderWindow& window);
	int returnType() { return typeID; }
	int returnID() { return objID; }
	sf::Vector2f getPosition() { return body.getPosition(); }
	Collider getCollider() { return Collider(body); }
private:
	sf::RectangleShape body;
	int typeID;
	int objID;
};

