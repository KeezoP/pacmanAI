#include "Wall.h"

Wall::Wall(sf::Vector2f size, sf::Vector2f position, int colourID, int uniqueID)
{
	switch (colourID) {
	case 0:
		body.setFillColor(sf::Color::Color(2.0f, 0.0f, 153.0f, 255.0f));
		break;
	case 1:
		body.setFillColor(sf::Color::Red);
		break;
	case 2:
		body.setFillColor(sf::Color::Green);
		break;
	case 3:
		body.setFillColor(sf::Color::Yellow);
		break;
	case 4:
		body.setFillColor(sf::Color::Black);
		break;

	}
	typeID = colourID;

	body.setSize(size);
	body.setOrigin(size / 2.0f);
	body.setPosition(position);
	objID = uniqueID;
}

Wall::~Wall()
{

}

void Wall::Draw(sf::RenderWindow& window)
{
	window.draw(body);
}
